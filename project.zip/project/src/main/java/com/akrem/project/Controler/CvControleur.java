package com.akrem.project.Controler;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.akrem.project.dao.CondidatRepository;
import com.akrem.project.dao.CvRepository;
import com.akrem.project.dao.OffreRepository;
import com.akrem.project.entit.Condidat;
import com.akrem.project.entit.Cv;
import com.akrem.project.entit.Offre;

@CrossOrigin("*")
@RestController
@RequestMapping("/cv")
public class CvControleur {

	@Autowired
    private CvRepository cvRepository;
    @Autowired
    private CondidatRepository condidatRepository;
    @Autowired
    private OffreRepository offreRepository;
    @PostMapping("/ajouter/{id}/{ido}")
    public Cv ajouterCv(@RequestBody Cv cv, @PathVariable Long id,@PathVariable Long ido) {
        Condidat condidat=condidatRepository.getOne(id );
        cv.setCondidat(condidat);
        Offre offre=offreRepository.getOne(ido);
        cv.setOffre(offre);
        return cvRepository.saveAndFlush(cv);
    }

    @GetMapping("/all")
    public List<Cv> getall() {
        return cvRepository.findAll();
    }

    @GetMapping("/all/{ido}")
    public List<Cv> getall(@PathVariable Long ido) {

        return cvRepository.findByOffre_id(ido);
    }
    @PutMapping("/update/{id}/{idc}")
    public Cv updateCv(@RequestBody Cv cv, @PathVariable Long id,@PathVariable Long idc) {
       Condidat condidat=condidatRepository.getOne(idc);
        cv.setId(id);
        cv.setCondidat(condidat);
        return cvRepository.saveAndFlush(cv);
    }
    @DeleteMapping("/delete")
    public HashMap<String, String> deleteCv(@PathVariable Long id) {
        HashMap<String, String> hashMap = new HashMap<>();
        try {
            cvRepository.deleteById(id);
            hashMap.put("state", "yes");
        } catch (Exception e) {
            hashMap.put("state", "no");
        }
        return hashMap;

    }

    @GetMapping("/getprofil/{id}")
    public Cv getbyId(@PathVariable Long id) {

        return cvRepository.getOne(id);
    }
}
