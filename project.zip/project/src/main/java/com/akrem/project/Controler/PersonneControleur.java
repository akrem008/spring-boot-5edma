package com.akrem.project.Controler;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.akrem.project.dao.PersonneRepository;
import com.akrem.project.entit.Personne;

@RestController
@RequestMapping("/personne")
public class PersonneControleur {
	

	@Autowired
    private PersonneRepository personneRepository;

    @PostMapping("/ajouter")
    public Personne ajouterPersonne(@RequestBody Personne personne) {
        return personneRepository.save(personne);
    }

    @GetMapping("/all")
    public List<Personne> getall() {
        return personneRepository.findAll();
    }

    @PutMapping("/update/{id}")
    public Personne updatePersonne(@RequestBody Personne personne, @PathVariable Long id) {
        personne.setId(id);
        return personneRepository.saveAndFlush(personne);
    }
    @DeleteMapping("/delete/{id}")
    public HashMap<String, String> deletePersonne(@PathVariable Long id) {
        HashMap<String, String> hashMap = new HashMap<>();
        try {
            personneRepository.deleteById(id);
            hashMap.put("state", "yes");
        } catch (Exception e) {
            hashMap.put("state", "no");
        }
        return hashMap;

    }
    @GetMapping("/getprofil/{id}")
    public Personne getbyId(@PathVariable Long id) {

        return personneRepository.getOne(id);
    }

}
