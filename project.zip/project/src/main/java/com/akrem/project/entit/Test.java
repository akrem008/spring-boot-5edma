package com.akrem.project.entit;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;


@Entity
public class Test {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String questions;
    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getQuestions() {
		return questions;
	}

	public void setQuestions(String questions) {
		this.questions = questions;
	}

	public Collection<Condidat> getCondidats() {
		return condidats;
	}

	public void setCondidats(Collection<Condidat> condidats) {
		this.condidats = condidats;
	}

	@ManyToMany(fetch = FetchType.EAGER)
    private Collection<Condidat> condidats=new ArrayList<>();

	public Test() {
		// TODO Auto-generated constructor stub
	}

}
