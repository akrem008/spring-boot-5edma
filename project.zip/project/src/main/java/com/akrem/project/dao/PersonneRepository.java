package com.akrem.project.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.akrem.project.entit.Personne;

public interface PersonneRepository extends JpaRepository<Personne,Long>{

}
