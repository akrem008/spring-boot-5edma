package com.akrem.project.Controler;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.akrem.project.dao.OffreRepository;
import com.akrem.project.dao.RecruteurRepository;
import com.akrem.project.entit.Offre;
import com.akrem.project.entit.Recruteur;

@CrossOrigin("*")
@RestController
@RequestMapping("/offre")
public class OffreControleur {

	@Autowired
    private OffreRepository offreRepository;

    @Autowired
    private RecruteurRepository recruteurRepository;

    @PostMapping("/ajouter/{id}")
    public Offre ajouterOffre(@RequestBody Offre offre, @PathVariable Long id) {
        Recruteur recruteur=recruteurRepository.getOne(id );
        offre.setR(recruteur);
        return offreRepository.saveAndFlush(offre);
    }

    @GetMapping("/allfilter/{loc}/{duree}/{title}")
    public List<Offre> login(@PathVariable String loc,@PathVariable String duree,@PathVariable String title) {

        return offreRepository.getbyfilter(loc,duree,title);
    }

    @GetMapping("/all")
    public List<Offre> getall() {
        return offreRepository.findAll();
    }
    @GetMapping("/all/{idr}")
    public List<Offre> getall(@PathVariable Long idr) {

        return offreRepository.findByR_id(idr);
    }
    @PutMapping("/update/{ido}/{idr}")
    public Offre updateOffre(@RequestBody Offre offre, @PathVariable Long ido, @PathVariable Long idr) {
    Recruteur recruteur=recruteurRepository.getOne(idr);
    offre.setId(ido);
    offre.setR(recruteur);

        return offreRepository.saveAndFlush(offre);
    }
    @DeleteMapping("/delete/{id}")
    public HashMap<String, String> deleteOffre(@PathVariable Long id) {
        HashMap<String, String> hashMap = new HashMap<>();
        try {
            offreRepository.deleteById(id);
            hashMap.put("state", "yes");
        } catch (Exception e) {
            hashMap.put("state", "no");
        }

        return hashMap;

    }
    @GetMapping("/getprofil/{id}")
    public Offre getbyId(@PathVariable Long id) {

        return offreRepository.getOne(id);
    }
}
