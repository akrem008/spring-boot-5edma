package com.akrem.project.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.akrem.project.entit.Admin;

public interface AdminRepository extends JpaRepository<Admin,Long>  {
	 @Query("select e from Admin e where e.login= :login and e.password= :password")
	   Admin login(@Param("login") String login, @Param("password") String password);

}
