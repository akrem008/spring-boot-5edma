package com.akrem.project.Controler;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.akrem.project.dao.CondidatRepository;
import com.akrem.project.entit.Condidat;

@CrossOrigin("*")
@RestController
@RequestMapping("/condidat")
public class CondidatControleur {

	@Autowired
    private CondidatRepository condidatRepository;

    @PostMapping("/ajouter")
    public Condidat ajouterCondidat(@RequestBody Condidat condidat) {
        return condidatRepository.save(condidat);
    }

    @GetMapping("/all")
    public List<Condidat> getall() {
        return condidatRepository.findAll();
    }

    @GetMapping("/allfilter/{nom}/{formation}")
    public List<Condidat> getfilter(@PathVariable String nom, @PathVariable String formation) {

        return condidatRepository.getbyfilter(nom,formation);
    }
    @PutMapping("/update/{id}")
    public Condidat updateCondidat(@RequestBody Condidat condidat, @PathVariable Long id) {
        condidat.setId(id);
        return condidatRepository.saveAndFlush(condidat);
    }
    @DeleteMapping("/delete")
    public HashMap<String, String> deleteCondidat(@PathVariable Long id) {
        HashMap<String, String> hashMap = new HashMap<>();
        try {
            condidatRepository.deleteById(id);
            hashMap.put("state", "yes");
        } catch (Exception e) {
            hashMap.put("state", "no");
        }
        return hashMap;

    }

    @GetMapping("/getprofil/{id}")
    public Condidat getbyId(@PathVariable Long id) {

        return condidatRepository.getOne(id);
    }
    @PostMapping("/connexion")
    public Condidat login(@RequestBody Condidat condidat) {
        return condidatRepository.login(condidat.getLogin(), condidat.getPassword());
    }

}
