package com.akrem.project.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.akrem.project.entit.Cv;

public interface CvRepository extends JpaRepository<Cv,Long> {
	public List<Cv> findByOffre_id(Long id);

}
