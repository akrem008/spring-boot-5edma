package com.akrem.project.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.akrem.project.entit.Recruteur;

public interface RecruteurRepository extends JpaRepository<Recruteur,Long> {
	 @Query("select e from Recruteur e where e.login= :login and e.password= :password")
	    Recruteur login(@Param("login") String login, @Param("password") String password);

}
