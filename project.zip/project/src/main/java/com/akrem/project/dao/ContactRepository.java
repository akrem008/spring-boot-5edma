package com.akrem.project.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.akrem.project.entit.Contact;

public interface ContactRepository extends JpaRepository<Contact,Long>{

}
