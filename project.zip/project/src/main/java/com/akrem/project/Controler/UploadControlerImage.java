package com.akrem.project.Controler;

public class UploadControlerImage {

	public UploadControlerImage() {
		// TODO Auto-generated constructor stub
	}

}
