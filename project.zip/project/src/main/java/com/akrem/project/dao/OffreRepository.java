package com.akrem.project.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.akrem.project.entit.Offre;

public interface OffreRepository extends JpaRepository<Offre,Long> {
	public List<Offre> findByR_id(Long id);
    @Query("select o from Offre o where o.duree= :duree and o.localisation= :localisation and o.title= :title")
    public List<Offre> getbyfilter(@Param("localisation")String localisation,@Param("duree") String duree,@Param("title") String title);

}
