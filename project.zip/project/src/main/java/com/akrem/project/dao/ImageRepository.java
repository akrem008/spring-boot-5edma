package com.akrem.project.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.akrem.project.entit.ImageModel;

public interface ImageRepository extends JpaRepository<ImageModel, Long> {
	Optional<ImageModel> findByName(String name);

}
